from flask import Flask, request, jsonify, render_template

app = Flask(__name__)

@app.route('/upload', methods=['POST'])
def upload_csv():
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided.'}), 400
    
    file = request.files['file']
    
    if file.filename == '':
        return jsonify({'error': 'Empty filename provided.'}), 400
    
    if file and file.filename.endswith('.csv'):
        # Do something with the CSV file
        return jsonify({'message': 'File successfully uploaded.'}), 200
    
    return jsonify({'error': 'Only CSV files are allowed.'}), 400

if __name__ == '__main__':
    app.run(debug=False)

